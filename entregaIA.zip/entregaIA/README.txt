

--------------------------------------------------------------------------------------
Práctica 2 de Inteligencia Artificial  [Grau - IA]
Personalización de visitas a un museo aplicando sistemas basados en el conocimiento.


Curso 2016-2017 
Ismael Julià - Ana Mestre - Gorka Piñol

--------------------------------------------------------------------------------------

- Distribución práctica: 
  En esta carpeta hay 4 documentos:
  - README.txt: con las instrucciones de como ejecutar la práctica.
  - Memoria.pdf: archivo con toda la documentación de la práctica.
  - Anexo.pdf: archivo anexo a la práctica con los juegos de prueba realizados.
  - museo.clp: ejecutable de la práctica en código CLIPS.
  

--------------------------------------------------------------------------------------

- Cómo ejecutar la práctica:
  - Hay que abrir el CLIPS IDE, hacer un load de "museo.clp", primero ejecutar el 
    comando "(reset)" y seguidamente "(run)".
  - Primero tendrá que contestar una serie de preguntas para personalizar su experiencia 
    en nuestro museo y finalmente recibirá nuestra sugerencia de recorrido.
